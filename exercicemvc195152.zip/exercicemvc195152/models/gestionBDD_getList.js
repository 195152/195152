let Formation = require('./userModel');


function getlistrooms(callback){
    
    var mysql = require ("mysql");
    //database connection

    var connection = mysql.createConnection({
        host : 'localhost',
        user : 'root',
        password : 'sousou123',
        database : 'users'
    });
    let listrooms =[];

    connection.connect(function(error){if (error) console.log(error);});
    //connection.query()
   
    connection.query("select * from rooms;",function(error, result){//fct query qui accede à la abse de donnée et puis executer function
        if (error) console(error);
        for(let i = 0 ; i < result.length ; i++)
        {
            let element = new Formation(result[i]["id"],result[i]["name"],result[i]["length"],result[i]["width"])
            
            
            listrooms.push(element);
        }
        
        
        callback(listrooms);
    });
}
module.exports = getlistrooms;